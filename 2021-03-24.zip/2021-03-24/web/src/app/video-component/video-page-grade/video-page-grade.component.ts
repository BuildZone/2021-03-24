import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-video-page-grade',
  templateUrl: './video-page-grade.component.html',
  styleUrls: ['./video-page-grade.component.css']
})
export class VideoPageGradeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
