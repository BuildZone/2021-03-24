export interface Upload {
  _id: string;
  subjectname :string;
  name: string;
  teachername:string
  videoPath: string;
  insertgrade:string
}
