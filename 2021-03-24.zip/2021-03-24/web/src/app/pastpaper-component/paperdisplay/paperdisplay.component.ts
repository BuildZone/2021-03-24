import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paperdisplay',
  templateUrl: './paperdisplay.component.html',
  styleUrls: ['./paperdisplay.component.css']
})
export class PaperdisplayComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

