import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paper-dis',
  templateUrl: './paper-dis.component.html',
  styleUrls: ['./paper-dis.component.css']
})
export class PaperDisComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
