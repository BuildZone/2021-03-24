const mongoose = require('mongoose')

module.exports =mongoose.model('grade07paper',{
    name:String,
    paperPath:String,
   
   
    subjectname:String

})
